import type { ReactNode } from 'react';
import { ArrowDownLeft } from 'lucide-react';

export function PageHeader({ eyebrow, title, description, action }: { eyebrow?: string; title: string; description?: string; action?: ReactNode }) {
  return <div className="page-header">
    <div>{eyebrow && <div className="page-eyebrow">{eyebrow}</div>}<h1>{title}</h1>{description && <p>{description}</p>}</div>
    {action && <div className="page-header-action">{action}</div>}
  </div>;
}

export function SectionHeading({ title, description, action }: { title: string; description?: string; action?: ReactNode }) {
  return <div className="section-title-row"><div><h2>{title}</h2>{description && <p>{description}</p>}</div>{action}</div>;
}

export function StatusBadge({ children, tone = 'muted' }: { children: ReactNode; tone?: string }) {
  return <span className={`status-badge tone-${tone}`}><i />{children}</span>;
}

export function ProgressBar({ value, color }: { value: number; color?: string }) {
  const normalized = Math.max(0, Math.min(100, value));
  return <div className="progress-track" role="progressbar" aria-label={`نسبة الإنجاز ${normalized}%`} aria-valuemin={0} aria-valuemax={100} aria-valuenow={normalized}><span style={{ width: `${normalized}%`, background: color }} /></div>;
}

export function StatCard({ label, value, note, icon: Icon, color = 'blue' }: { label: string; value: string | number; note: string; icon: React.ComponentType<{ size?: number; strokeWidth?: number }>; color?: string }) {
  return <article className="stat-card">
    <div className="stat-card-top"><span className={`stat-icon icon-${color}`}><Icon size={18} strokeWidth={1.8} /></span></div>
    <div className="stat-label">{label}</div><div className="stat-value">{value}</div>
    <div className="stat-note"><span>{note}</span></div>
  </article>;
}

export function EmptyState({ title, description, action }: { title: string; description: string; action?: ReactNode }) {
  return <div className="empty-state"><span className="empty-mark"><ArrowDownLeft size={21} /></span><h3>{title}</h3><p>{description}</p>{action}</div>;
}

export function SectionCard({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <section className={`section-card ${className}`}>{children}</section>;
}
