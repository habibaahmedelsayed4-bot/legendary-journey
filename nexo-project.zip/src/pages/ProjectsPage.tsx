import { useMemo, useState } from 'react';
import { Archive, ArrowLeft, ArrowUpLeft, CalendarDays, Check, ChevronLeft, FolderOpen, MoreHorizontal, Pencil, Plus, RotateCcw, Trash2, UploadCloud } from 'lucide-react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { useWorkspace, statusTone } from '../app/WorkspaceContext';
import { ConfirmDialog } from '../app/ConfirmDialog';
import { FileActions } from '../app/FileActions';
import { ProjectDialog } from '../app/ProjectDialog';
import { RelativeTime } from '../app/RelativeTime';
import { TaskDialog } from '../app/TaskDialog';
import { deleteLocalFiles, formatBytes, saveLocalFile } from '../data/storage';
import { formatDueDate } from '../data/format';
import type { Project, ProjectStatus, Task } from '../data/model';
import { EmptyState, PageHeader, ProgressBar, SectionCard, SectionHeading, StatusBadge } from './Shared';

function ProjectActions({ project, onDeleted }: { project: Project; onDeleted?: () => void }) {
  const { state, updateProject, deleteProject } = useWorkspace();
  const [editing, setEditing] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const taskCount = state.tasks.filter((task) => task.projectId === project.id).length;
  const files = state.files.filter((file) => file.projectId === project.id);

  const removeProject = async () => {
    setBusy(true);
    setError('');
    const removed = await deleteProject(project.id);
    setBusy(false);
    if (removed) {
      setConfirmDelete(false);
      onDeleted?.();
    } else setError('تعذر حذف المشروع وملفاته المحلية. لم يُعتمد الحذف.');
  };

  return <>
    <details className="entity-actions-menu project-actions-menu">
      <summary className="entity-actions-trigger" aria-label={`إجراءات المشروع ${project.name}`} title="إجراءات المشروع"><MoreHorizontal size={17} /></summary>
      <div className="entity-actions-panel" role="group" aria-label={`إجراءات ${project.name}`}>
        <button type="button" onClick={() => setEditing(true)}><Pencil size={14} />تعديل المشروع</button>
        <button type="button" onClick={() => updateProject(project.id, { archived: !project.archived })}>{project.archived ? <RotateCcw size={14} /> : <Archive size={14} />}{project.archived ? 'استعادة من الأرشيف' : 'أرشفة المشروع'}</button>
        <button type="button" className="danger-action" onClick={() => setConfirmDelete(true)}><Trash2 size={14} />حذف المشروع</button>
      </div>
    </details>
    {error && <span className="entity-action-error" role="alert">{error}</span>}
    {editing && <ProjectDialog project={project} onClose={() => setEditing(false)} />}
    {confirmDelete && <ConfirmDialog title="حذف المشروع؟" description={`سيُحذف «${project.name}» نهائيًا مع ${taskCount} ${taskCount === 1 ? 'مهمة' : 'مهمة'} و${files.length} ${files.length === 1 ? 'ملف' : 'ملفًا'} وسجل نشاطه. سيُحذف محتوى ملفاته المحلية من هذا الجهاز. لا يمكن التراجع عن هذا الإجراء.`} confirmLabel="حذف المشروع وبياناته" busy={busy} onConfirm={removeProject} onClose={() => { if (!busy) setConfirmDelete(false); }} />}
  </>;
}

export function WorkspacePage() {
  const { state } = useWorkspace();
  const activeProjects = state.projects.filter((project) => !project.archived);
  const activeIds = new Set(activeProjects.map((project) => project.id));
  const completion = activeProjects.length ? Math.round(activeProjects.reduce((sum, project) => sum + project.progress, 0) / activeProjects.length) : 0;
  const openTasks = state.tasks.filter((task) => activeIds.has(task.projectId) && task.status !== 'مكتملة');
  return <main className="page-content"><PageHeader eyebrow="نظرة عامة" title={state.workspaceName} description="مساحة واحدة تجمع المشاريع والمهام والملفات التي تعمل عليها." />
    <div className="workspace-hero-card"><div className="workspace-hero-mark"><span className="brand-mark"><i /><i /></span></div><div className="workspace-hero-copy"><span className="eyebrow">مساحة شخصية</span><h2>مساحة عملك، بوضوح.</h2><p>بيانات هذه المساحة محفوظة على جهازك. أضف مشروعًا جديدًا أو واصل من حيث توقفت.</p></div><Link className="button button-primary" to="/app/projects">استعرض المشاريع <ArrowLeft size={16} /></Link></div>
    <div className="workspace-stats-row"><div><span>المشاريع الحالية</span><strong>{activeProjects.length}</strong><small>غير مؤرشفة</small></div><div><span>المهام النشطة</span><strong>{openTasks.length}</strong><small>تحتاج إلى متابعة</small></div><div><span>متوسط الإنجاز</span><strong>{completion}%</strong><small title="متوسط نسبة إنجاز المشاريع الحالية">متوسط نسبة إنجاز المشاريع الحالية</small></div><div><span>الملفات</span><strong>{state.files.length}</strong><small>ملف محفوظ محليًا</small></div></div>
    <SectionCard><SectionHeading title="معلومات المساحة" description="تخصيص بسيط لمساحتك الحالية" /><div className="workspace-detail-grid"><div><span>اسم المساحة</span><strong>{state.workspaceName}</strong></div><div><span>المالك</span><strong>{state.name}</strong></div><div><span>مكان حفظ البيانات</span><strong>هذا المتصفح فقط</strong></div></div></SectionCard>
  </main>;
}

export function ProjectsPage() {
  const { state } = useWorkspace();
  const [projectDialog, setProjectDialog] = useState<'new' | Project | null>(null);
  const [searchText, setSearchText] = useState('');
  const [filter, setFilter] = useState('الكل');
  const [showArchived, setShowArchived] = useState(false);
  const visible = state.projects.filter((project) => project.archived === showArchived);
  const filtered = useMemo(() => visible.filter((project) => (filter === 'الكل' || project.status === filter) && `${project.name} ${project.description}`.toLowerCase().includes(searchText.trim().toLowerCase())), [filter, searchText, state.projects, showArchived]);
  const openProjectDialog = (project?: Project) => setProjectDialog(project ?? 'new');
  return <main className="page-content"><PageHeader eyebrow="إدارة العمل" title="المشاريع" description="كل مشروع له مساره. تابع التقدم واعرف الخطوة القادمة." action={<button type="button" className="button button-primary" onClick={() => openProjectDialog()}><Plus size={16} />مشروع جديد</button>} />
    <div className="project-view-tabs" role="group" aria-label="عرض المشاريع"><button type="button" aria-pressed={!showArchived} className={!showArchived ? 'selected' : ''} onClick={() => { setShowArchived(false); setFilter('الكل'); }}>المشاريع الحالية <span>{state.projects.filter((project) => !project.archived).length}</span></button><button type="button" aria-pressed={showArchived} className={showArchived ? 'selected' : ''} onClick={() => { setShowArchived(true); setFilter('الكل'); }}>الأرشيف <span>{state.projects.filter((project) => project.archived).length}</span></button></div>
    <div className="toolbar-row"><div className="filter-pills" aria-label="تصفية حالة المشروع">{['الكل', 'قيد التنفيذ', 'قيد المراجعة', 'مكتمل'].map((item) => <button type="button" key={item} aria-pressed={filter === item} className={`filter-pill${filter === item ? ' selected' : ''}`} onClick={() => setFilter(item)}>{item}{item === 'الكل' && <span>{visible.length}</span>}</button>)}</div><label className="search-control"><span className="sr-only">ابحث عن مشروع</span><input aria-label="ابحث عن مشروع" value={searchText} onChange={(event) => setSearchText(event.target.value)} placeholder="ابحث عن مشروع" /></label></div>
    {filtered.length ? <div className="projects-grid">{filtered.map((project) => <article className="project-card-shell" key={project.id}>
      <Link to={`/app/projects/${project.id}`} className="project-card">
        <div className="project-card-top"><span className="project-card-icon" style={{ color: project.color, background: `${project.color}18` }}><FolderOpen size={18} /></span>{project.archived && <span className="archived-chip">مؤرشف</span>}</div>
        <div className="project-card-meta"><StatusBadge tone={statusTone(project.status)}>{project.status}</StatusBadge><span className="updated-label"><CalendarDays size={13} />{project.updatedAt ? <RelativeTime value={project.updatedAt} /> : 'وقت غير متاح'}</span></div>
        <h3>{project.name}</h3><p className="project-card-description">{project.description || 'لا يوجد وصف للمشروع.'}</p>
        <div className="project-card-progress"><div><span>نسبة الإنجاز</span><strong>{project.progress}%</strong></div><ProgressBar value={project.progress} color={project.color} /></div>
        <div className="project-card-footer"><span><Check size={14} />{project.tasksCount} مهمة</span><span className="project-card-people"><i>{state.name.slice(0, 1) || 'ن'}</i><small>مساحة شخصية</small></span><ArrowUpLeft size={16} className="row-arrow" /></div>
      </Link>
      <ProjectActions project={project} />
    </article>)}</div> : <EmptyState title={visible.length ? 'لا توجد مشاريع مطابقة' : showArchived ? 'لا توجد مشاريع مؤرشفة' : 'ابدأ بمشروعك الأول'} description={visible.length ? 'جرّب تغيير كلمات البحث أو المرشّحات.' : showArchived ? 'عند أرشفة مشروع سيظهر هنا، من دون حذف بياناته.' : 'أضف مشروعًا؛ سيبدأ تقدمه من 0% ويرتفع مع إنجاز المهام.'} action={!showArchived && <button type="button" className="button button-primary" onClick={() => openProjectDialog()}><Plus size={16} />{visible.length ? 'مشروع جديد' : 'إنشاء مشروع'}</button>} />}
    {projectDialog && <ProjectDialog project={projectDialog === 'new' ? undefined : projectDialog} onClose={() => setProjectDialog(null)} />}
  </main>;
}

function ProjectTaskRow({ task, onEdit, onDelete }: { task: Task; onEdit: () => void; onDelete: () => void }) {
  const { updateTaskStatus } = useWorkspace();
  return <article className={`project-task-row${task.status === 'مكتملة' ? ' task-card-done' : ''}`}>
    <label className="task-complete-control"><input type="checkbox" checked={task.status === 'مكتملة'} onChange={() => updateTaskStatus(task.id, task.status === 'مكتملة' ? 'قيد التنفيذ' : 'مكتملة')} /><span className="task-check-visual"><Check size={13} /></span><span className="sr-only">{task.status === 'مكتملة' ? 'إعادة فتح المهمة' : 'إكمال المهمة'}</span></label>
    <span className="project-task-copy"><strong className={task.status === 'مكتملة' ? 'task-complete-text' : ''}>{task.name}</strong><small>{task.priority} الأولوية · {formatDueDate(task.dueDate)}</small></span>
    <span className="project-task-status"><StatusBadge tone={statusTone(task.status)}>{task.status}</StatusBadge></span>
    <details className="entity-actions-menu"><summary className="entity-actions-trigger" aria-label={`إجراءات المهمة ${task.name}`}><MoreHorizontal size={17} /></summary><div className="entity-actions-panel" role="group"><button type="button" onClick={onEdit}><Pencil size={14} />تعديل المهمة</button><button type="button" className="danger-action" onClick={onDelete}><Trash2 size={14} />حذف المهمة</button></div></details>
  </article>;
}

export function ProjectDetailPage() {
  const { projectId } = useParams();
  const { state, addFile, deleteTask, updateProject } = useWorkspace();
  const navigate = useNavigate();
  const project = state.projects.find((item) => item.id === projectId);
  const tasks = state.tasks.filter((task) => task.projectId === projectId);
  const files = state.files.filter((file) => file.projectId === projectId);
  const projectActivities = state.activities.filter((activity) => activity.projectId === projectId);
  const [activeTab, setActiveTab] = useState('المهام');
  const [taskDialogOpen, setTaskDialogOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [deletingTask, setDeletingTask] = useState<Task | null>(null);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');
  if (!project) return <main className="page-content"><PageHeader title="المشروع غير موجود" description="قد يكون المشروع قد أُزيل من هذه المساحة." /><Link to="/app/projects" className="button button-primary">العودة إلى المشاريع</Link></main>;

  const upload = async (file?: File) => {
    if (!file) return;
    setNotice('');
    if (file.size > 20 * 1024 * 1024) { setNotice('الحد الأقصى للملف الواحد هو 20 ميغابايت.'); return; }
    const id = `file-${crypto.randomUUID?.() ?? Date.now()}`;
    setBusy(true);
    try {
      await saveLocalFile(id, file);
      const added = addFile({ id, name: file.name, type: file.name.includes('.') ? file.name.split('.').pop()!.toUpperCase() : file.type.split('/')[1]?.toUpperCase() ?? 'FILE', size: file.size, date: new Date().toISOString(), owner: state.name, localBlob: true, projectId: project.id });
      if (!added) { await deleteLocalFiles([id]); setNotice('تعذر حفظ بيانات الملف في مساحة العمل؛ لم يُعتمد الإضافة.'); }
      else setNotice(`حُفظ «${file.name}» على هذا الجهاز.`);
    } catch (error) {
      setNotice(error instanceof Error ? error.message : 'تعذر حفظ الملف.');
    } finally { setBusy(false); }
  };

  return <main className="page-content">
    <div className="breadcrumb-row"><Link className="back-link" to="/app/projects"><ArrowLeft size={15} />المشاريع</Link><ChevronLeft size={14} /><span>{project.name}</span></div>
    <section className="project-detail-hero"><div className="project-detail-heading"><span className="project-detail-icon" style={{ color: project.color, background: `${project.color}18` }}><FolderOpen size={21} /></span><div><div className="detail-title-row"><h1>{project.name}</h1><StatusBadge tone={statusTone(project.status)}>{project.status}</StatusBadge>{project.archived && <span className="archived-chip">مؤرشف</span>}</div><p>{project.description || 'لا يوجد وصف للمشروع.'}</p><small className="project-last-updated">آخر تحديث: <RelativeTime value={project.updatedAt} /></small></div></div>
      <div className="project-detail-controls"><label className="status-select-label"><span>حالة المشروع</span><select value={project.status} onChange={(event) => updateProject(project.id, { status: event.target.value as ProjectStatus })}><option>قيد التنفيذ</option><option>قيد المراجعة</option><option>مكتمل</option></select></label><ProjectActions project={project} onDeleted={() => navigate('/app/projects', { replace: true })} /></div>
      <div className="detail-hero-meta"><div><span>نسبة الإنجاز</span><strong>{project.progress}%</strong></div><div className="detail-progress"><ProgressBar value={project.progress} color={project.color} /></div></div>
    </section>
    <div className="detail-tabs" role="tablist" aria-label="محتوى المشروع">{['المهام', 'الملفات', 'النشاط'].map((tab) => <button type="button" role="tab" aria-selected={activeTab === tab} className={activeTab === tab ? 'active' : ''} key={tab} onClick={() => setActiveTab(tab)}>{tab}{tab === 'المهام' && <span>{tasks.length}</span>}</button>)}</div>
    {notice && <div className="inline-notice" role="status">{notice}</div>}
    {activeTab === 'المهام' && <SectionCard className="detail-panel"><SectionHeading title="مهام المشروع" description={`${tasks.length} مهمة مرتبطة بهذا المشروع`} action={<button type="button" className="button button-primary button-sm" onClick={() => { setEditingTask(null); setTaskDialogOpen(true); }}><Plus size={15} />إضافة مهمة</button>} />
      {tasks.length ? <div className="detail-task-list">{tasks.map((task) => <ProjectTaskRow key={task.id} task={task} onEdit={() => { setEditingTask(task); setTaskDialogOpen(true); }} onDelete={() => setDeletingTask(task)} />)}</div> : <EmptyState title="لا توجد مهام بعد" description="أضف أول مهمة لهذا المشروع. لن يتغير التقدم إلا عند إكمالها." action={<button type="button" className="button button-outline button-sm" onClick={() => { setEditingTask(null); setTaskDialogOpen(true); }}><Plus size={14} />إضافة مهمة</button>} />}
    </SectionCard>}
    {activeTab === 'الملفات' && <SectionCard className="detail-panel"><SectionHeading title="ملفات المشروع" description="المعاينة والتنزيل والإدارة من تخزين هذا الجهاز" action={<label className={`button button-primary button-sm file-pick-button${busy ? ' disabled' : ''}`}>{busy ? 'جارٍ الحفظ…' : 'إضافة ملف'}<UploadCloud size={15} /><input type="file" disabled={busy} onChange={(event) => { void upload(event.target.files?.[0]); event.currentTarget.value = ''; }} /></label>} /><div className="local-info-banner">الملفات التي تختارها تبقى في تخزين هذا المتصفح فقط.</div>{files.length ? <div className="detail-file-list">{files.map((file) => <div className="detail-file-row" key={file.id}><span className="file-mini-mark">{file.type}</span><span className="detail-file-name">{file.name}<small>{formatBytes(file.size)}</small></span><FileActions file={file} compact /></div>)}</div> : <EmptyState title="أضف ملفات المشروع" description="اختر ملفًا من جهازك لإضافته إلى مساحة العمل المحلية." />}</SectionCard>}
    {activeTab === 'النشاط' && <SectionCard className="detail-panel"><SectionHeading title="نشاط المشروع" description="آخر ما حدث في هذا المشروع" />{projectActivities.length ? projectActivities.slice(0, 8).map((activity) => <article className="detail-activity-row" key={activity.id}><span className="timeline-node" /><div><strong>{activity.title}</strong><p>{activity.description}</p></div><RelativeTime value={activity.createdAt} /></article>) : <EmptyState title="لا يوجد نشاط بعد" description="ستظهر هنا التحديثات الفعلية لهذا المشروع." />}</SectionCard>}
    {taskDialogOpen && <TaskDialog task={editingTask ?? undefined} initialProjectId={project.id} onClose={() => { setTaskDialogOpen(false); setEditingTask(null); }} />}
    {deletingTask && <ConfirmDialog title="حذف المهمة؟" description={`سيُحذف «${deletingTask.name}» من المشروع. ستُعاد نسبة الإنجاز حسب المهام المتبقية.`} confirmLabel="حذف المهمة" onConfirm={() => { deleteTask(deletingTask.id); setDeletingTask(null); }} onClose={() => setDeletingTask(null)} />}
  </main>;
}
