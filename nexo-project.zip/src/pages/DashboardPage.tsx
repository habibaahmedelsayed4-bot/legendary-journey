import { Activity, AlertTriangle, ArrowLeft, ArrowUpLeft, CalendarClock, CheckCheck, FolderKanban, Plus, UploadCloud } from 'lucide-react';
import { Link } from 'react-router-dom';
import { RelativeTime } from '../app/RelativeTime';
import { useWorkspace, statusTone } from '../app/WorkspaceContext';
import { formatDueDate, localDateKey } from '../data/format';
import { EmptyState, ProgressBar, SectionCard, SectionHeading, StatCard, StatusBadge } from './Shared';

export function DashboardPage() {
  const { state } = useWorkspace();
  const now = new Date();
  const today = localDateKey(now);
  const dateLabel = new Intl.DateTimeFormat('ar-EG-u-ca-gregory-nu-latn', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).format(now);
  const greeting = now.getHours() < 12 ? 'صباح الخير' : 'مساء الخير';
  const visibleProjects = state.projects.filter((project) => !project.archived);
  const activeProjects = visibleProjects.filter((project) => project.status !== 'مكتمل');
  const visibleProjectIds = new Set(visibleProjects.map((project) => project.id));
  const openTasks = state.tasks.filter((task) => task.status !== 'مكتملة' && visibleProjectIds.has(task.projectId));
  const overdueTasks = openTasks.filter((task) => task.dueDate && task.dueDate < today).sort((a, b) => a.dueDate.localeCompare(b.dueDate));
  const upcomingTasks = openTasks.filter((task) => task.dueDate && task.dueDate >= today).sort((a, b) => a.dueDate.localeCompare(b.dueDate)).slice(0, 4);
  const recentProjects = visibleProjects.slice(0, 4);
  const overdueProjectCounts = overdueTasks.reduce<Record<string, number>>((counts, task) => ({ ...counts, [task.projectId]: (counts[task.projectId] ?? 0) + 1 }), {});
  const attentionProjectId = Object.entries(overdueProjectCounts).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))[0]?.[0];
  const attentionProject = visibleProjects.find((project) => project.id === attentionProjectId);
  const lastActivity = state.activities[0];
  const focusTitle = overdueTasks[0]?.name ?? upcomingTasks[0]?.name ?? (activeProjects.length ? 'أضف أول مهمة إلى مشروعك' : 'ابدأ بإنشاء مشروعك الأول');
  const focusDescription = overdueTasks.length ? `لديك ${overdueTasks.length} ${overdueTasks.length === 1 ? 'مهمة متأخرة' : 'مهام متأخرة'} تحتاج إلى مراجعة.` : upcomingTasks[0] ? `أقرب استحقاق: ${formatDueDate(upcomingTasks[0].dueDate)}.` : 'سيبدأ احتساب التقدم من المهام التي تنجزها فعلًا.';
  const focusTo = activeProjects.length ? '/app/tasks' : '/app/projects';

  return <main className="page-content">
    <div className="dashboard-welcome-row">
      <div><div className="page-eyebrow"><time dateTime={now.toISOString()}>{dateLabel}</time> <span className="eyebrow-separator">/</span> مساحة يومك</div><h1>{greeting}، {state.name}<span className="greeting-sun" aria-hidden="true">✦</span></h1><p>إليك ما يحدث في مساحة عملك اليوم.</p></div>
      <Link className="button button-primary" to="/app/projects"><Plus size={16} />مشروع جديد</Link>
    </div>
    <div className="stats-grid">
      <StatCard label="المشاريع النشطة" value={activeProjects.length} note="مشروعًا غير مؤرشف" icon={FolderKanban} color="blue" />
      <StatCard label="المهام المكتملة" value={state.tasks.filter((task) => task.status === 'مكتملة' && visibleProjectIds.has(task.projectId)).length} note="مهمة أُنجزت فعلًا" icon={CheckCheck} color="mint" />
      <StatCard label="الملفات" value={state.files.length} note="ملفًا محفوظًا محليًا" icon={UploadCloud} color="amber" />
      <StatCard label="النشاط الأخير" value={state.activities.length} note="حدثًا مسجلًا فعليًا" icon={Activity} color="violet" />
    </div>
    <div className="dashboard-columns">
      <SectionCard className="projects-overview-card">
        <SectionHeading title="المشاريع الحالية" description="تابع التقدم من المهام التي تنجزها" action={<Link className="subtle-link" to="/app/projects">عرض كل المشاريع <ArrowLeft size={14} /></Link>} />
        <div className="project-overview-list">{recentProjects.length ? recentProjects.map((project) => <Link to={`/app/projects/${project.id}`} className="project-overview-row" key={project.id}>
          <span className="project-avatar" style={{ color: project.color, borderColor: `${project.color}45`, background: `${project.color}18` }}><span>{project.name.slice(0, 1)}</span></span>
          <span className="project-overview-info"><strong>{project.name}</strong><small>{project.description || 'لا يوجد وصف'}</small></span>
          <span className="project-progress-cell"><span className="progress-meta"><b>{project.progress}%</b><small>مكتمل</small></span><ProgressBar value={project.progress} color={project.color} /></span>
          <StatusBadge tone={statusTone(project.status)}>{project.status}</StatusBadge>
          <ArrowUpLeft size={16} className="row-arrow" />
        </Link>) : <EmptyState title="ابدأ بعملك الأول" description="أنشئ مشروعًا ثم أضف إليه مهامًا. ستظهر الأرقام والتقدم هنا من عملك الفعلي." action={<Link className="button button-primary button-sm" to="/app/projects"><Plus size={15} />إنشاء مشروع</Link>} />}</div>
      </SectionCard>
      <SectionCard className="activity-overview-card">
        <SectionHeading title="آخر نشاط فعلي" description="آخر تغيير سُجل في مساحتك" action={<Link className="round-arrow-link" to="/app/activity" aria-label="عرض سجل النشاط"><ArrowLeft size={15} /></Link>} />
        {lastActivity ? <div className="activity-list compact-activity"><div className="activity-line"><span className={`activity-mark kind-${lastActivity.kind}`}><Activity size={14} /></span><div><strong>{lastActivity.title}</strong><p>{lastActivity.description}</p><small><RelativeTime value={lastActivity.createdAt} /></small></div></div></div> : <EmptyState title="لا يوجد نشاط بعد" description="ستظهر إنجازاتك وتحديثاتك هنا عند بدء العمل." />}
      </SectionCard>
    </div>
    <div className="dashboard-insights-grid">
      <SectionCard className="upcoming-tasks-card">
        <SectionHeading title="المهام الأقرب للاستحقاق" description="مهام غير مكتملة لها موعد محدد" action={<Link className="subtle-link" to="/app/tasks">كل المهام <ArrowLeft size={14} /></Link>} />
        {upcomingTasks.length ? <div className="upcoming-task-list">{upcomingTasks.map((task) => <Link to="/app/tasks" className="upcoming-task-row" key={task.id}><span className="upcoming-task-icon"><CalendarClock size={16} /></span><span className="upcoming-task-copy"><strong>{task.name}</strong><small>{visibleProjects.find((project) => project.id === task.projectId)?.name ?? 'مشروع'}</small></span><span className="upcoming-task-date">{formatDueDate(task.dueDate)}</span></Link>)}</div> : <EmptyState title="لا توجد استحقاقات قريبة" description="أضف تاريخًا اختياريًا لمهمة لتظهر هنا قبل موعدها." action={<Link className="button button-outline button-sm" to="/app/tasks">عرض المهام</Link>} />}
      </SectionCard>
      <SectionCard className="attention-project-card">
        <SectionHeading title="مشروع يحتاج متابعة" description="يعتمد على المهام المتأخرة فعلًا" />
        {attentionProject ? <Link to={`/app/projects/${attentionProject.id}`} className="attention-project-link"><span className="attention-icon"><AlertTriangle size={17} /></span><span><strong>{attentionProject.name}</strong><small>{overdueProjectCounts[attentionProject.id]} مهمة متأخرة · {attentionProject.progress}% إنجاز</small></span><ArrowLeft size={15} /></Link> : <EmptyState title="لا توجد مشاريع متأخرة" description={visibleProjects.length ? 'لا توجد مهام متأخرة في المشاريع الحالية.' : 'أنشئ مشروعًا وأضف مواعيد للمهام عند الحاجة.'} />}
      </SectionCard>
    </div>
    <SectionCard className="focus-card"><div className="focus-icon"><CheckCheck size={18} /></div><div className="focus-copy"><span>محطتك التالية</span><strong>{focusTitle}</strong><small>{focusDescription}</small></div><Link className="focus-action" to={focusTo}>{activeProjects.length ? 'إلى المهام' : 'إلى المشاريع'} <ArrowLeft size={14} /></Link></SectionCard>
  </main>;
}
