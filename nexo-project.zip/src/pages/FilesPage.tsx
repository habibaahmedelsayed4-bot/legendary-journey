import { useRef, useState } from 'react';
import { FileArchive, FileImage, FileSpreadsheet, FileText, FileUp, FolderOpen, Search, UploadCloud } from 'lucide-react';
import { useWorkspace } from '../app/WorkspaceContext';
import { FileActions } from '../app/FileActions';
import { formatDate } from '../data/format';
import { formatBytes, saveLocalFile, deleteLocalFiles } from '../data/storage';
import type { WorkspaceFile } from '../data/model';
import { EmptyState, PageHeader, SectionCard, SectionHeading } from './Shared';

function FileGlyph({ type }: { type: string }) {
  if (['PNG', 'JPG', 'JPEG', 'GIF', 'SVG', 'WEBP', 'AVIF'].includes(type)) return <FileImage size={19} />;
  if (['XLSX', 'CSV'].includes(type)) return <FileSpreadsheet size={19} />;
  if (['ZIP', 'RAR', '7Z'].includes(type)) return <FileArchive size={19} />;
  return <FileText size={19} />;
}

export function FilesPage() {
  const { state, addFile } = useWorkspace();
  const inputRef = useRef<HTMLInputElement>(null);
  const [query, setQuery] = useState('');
  const [notice, setNotice] = useState('');
  const [busy, setBusy] = useState(false);
  const files = state.files.filter((file) => `${file.name} ${file.type} ${file.owner}`.toLowerCase().includes(query.trim().toLowerCase()));

  const upload = async (file?: File) => {
    if (!file) return;
    setNotice('');
    if (file.size > 20 * 1024 * 1024) { setNotice('حجم الملف أكبر من الحد المسموح (20 ميغابايت).'); return; }
    const id = `file-${crypto.randomUUID?.() ?? `${Date.now()}`}`;
    setBusy(true);
    try {
      await saveLocalFile(id, file);
      const extension = file.name.includes('.') ? file.name.split('.').pop()!.toUpperCase() : file.type.split('/')[1]?.toUpperCase() ?? 'FILE';
      const record: WorkspaceFile = { id, name: file.name, type: extension, size: file.size, date: new Date().toISOString(), owner: state.name, localBlob: true };
      if (!addFile(record)) {
        await deleteLocalFiles([id]);
        setNotice('تعذر حفظ بيانات الملف في مساحة العمل؛ لم يُعتمد الإضافة.');
      } else setNotice(`تم حفظ «${file.name}» محليًا على هذا الجهاز.`);
    } catch (error) {
      setNotice(error instanceof Error ? error.message : 'تعذر حفظ الملف على هذا الجهاز.');
    } finally {
      setBusy(false);
      if (inputRef.current) inputRef.current.value = '';
    }
  };

  return <main className="page-content">
    <PageHeader eyebrow="مكتبة مساحة العمل" title="الملفات" description="ملفاتك قريبة من المشاريع التي تنتمي إليها." action={<button type="button" className="button button-primary" disabled={busy} onClick={() => inputRef.current?.click()}><UploadCloud size={16} />{busy ? 'جارٍ الحفظ…' : 'رفع ملف'}</button>} />
    <input ref={inputRef} className="sr-only" type="file" aria-label="اختر ملفًا من الجهاز" onChange={(event) => void upload(event.target.files?.[0])} />
    <div className="file-local-banner"><span className="local-banner-icon"><FolderOpen size={16} /></span><span><strong>تخزين محلي</strong><small>الملفات تحفظ في هذا المتصفح فقط ولا تُرفع إلى خادم.</small></span><span className="local-banner-chip">على هذا الجهاز</span></div>
    {notice && <div className="inline-notice" role="status">{notice}</div>}
    <SectionCard className="files-section"><SectionHeading title="كل الملفات" description={`${state.files.length} ملفًا في مساحة العمل`} action={<label className="search-control file-search"><span className="sr-only">ابحث عن ملف</span><Search size={15} /><input aria-label="ابحث عن ملف" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="ابحث عن ملف" /></label>} />
      <div className="file-list-head"><span>الملف</span><span>النوع</span><span>الحجم</span><span>تاريخ الإضافة</span><span>صاحب الملف</span><span>المشروع</span><span>إجراءات</span></div>
      {files.length ? <div className="file-list">{files.map((file) => {
        const project = state.projects.find((item) => item.id === file.projectId);
        return <article className="file-row" key={file.id}>
          <div className="file-name-cell"><span className={`file-type-icon type-${file.type.toLowerCase()}`}><FileGlyph type={file.type} /></span><span><strong>{file.name}</strong><small>{file.localBlob ? 'محفوظ على هذا الجهاز' : 'المحتوى المحلي غير متاح'}</small></span></div>
          <span className="file-type-cell">{file.type}</span><span className="file-size-cell">{formatBytes(file.size)}</span><span className="file-date-cell">{formatDate(file.date)}</span><span className="file-owner-cell">{file.owner || '—'}</span><span className="file-project-cell">{project?.name ?? 'المكتبة العامة'}</span>
          <FileActions file={file} />
        </article>;
      })}</div> : <EmptyState title={state.files.length ? 'لا توجد ملفات مطابقة' : 'مكتبة الملفات فارغة'} description={state.files.length ? 'جرّب اسمًا أو نوعًا آخر.' : 'أضف ملفًا من جهازك ليتوفر في مكتبتك ومشروعك.'} action={<button type="button" className="button button-primary" disabled={busy} onClick={() => inputRef.current?.click()}><FileUp size={15} />رفع ملف</button>} />}
    </SectionCard>
  </main>;
}
