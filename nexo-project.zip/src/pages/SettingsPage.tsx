import { useEffect, useRef, useState, type FormEvent } from 'react';
import { ArrowLeft, Bell, Check, ChevronLeft, CircleHelp, Download, Info, Monitor, Moon, ShieldCheck, Sun, Upload, ArchiveRestore } from 'lucide-react';
import { Link } from 'react-router-dom';
import { ConfirmDialog } from '../app/ConfirmDialog';
import { useWorkspace } from '../app/WorkspaceContext';
import { buildWorkspaceBackup, parseWorkspaceBackup, type ParsedBackup } from '../data/backup';
import { PageHeader, SectionCard, SectionHeading } from './Shared';

function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (next: boolean) => void; label: string }) {
  return <button type="button" role="switch" aria-checked={checked} aria-label={label} className={`toggle-switch${checked ? ' is-on' : ''}`} onClick={() => onChange(!checked)}><span /></button>;
}

export function SettingsPage() {
  const { state, saveSettings, updatePreferences, addActivity, replaceWorkspace } = useWorkspace();
  const [name, setLocalName] = useState(state.name);
  const [workspaceName, setLocalWorkspaceName] = useState(state.workspaceName);
  const [localAlerts, setLocalAlerts] = useState(state.preferences.localAlerts);
  const [projectNotifications, setProjectNotifications] = useState(state.preferences.projectNotifications);
  const [taskNotifications, setTaskNotifications] = useState(state.preferences.taskNotifications);
  const [saved, setSaved] = useState(false);
  const [feedback, setFeedback] = useState<{ kind: 'success' | 'error' | 'info'; text: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [pendingImport, setPendingImport] = useState<ParsedBackup | null>(null);
  const backupInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setLocalName(state.name);
    setLocalWorkspaceName(state.workspaceName);
    setLocalAlerts(state.preferences.localAlerts);
    setProjectNotifications(state.preferences.projectNotifications);
    setTaskNotifications(state.preferences.taskNotifications);
  }, [state.name, state.workspaceName, state.preferences.localAlerts, state.preferences.projectNotifications, state.preferences.taskNotifications]);

  const changeTheme = (theme: 'dark' | 'light') => {
    if (state.preferences.theme === theme) return;
    updatePreferences({ theme });
    addActivity({ title: 'تم تغيير مظهر مساحة العمل', description: `تم اختيار الوضع ${theme === 'light' ? 'الفاتح' : 'الداكن'}.`, kind: 'settings' });
  };

  const submit = (event: FormEvent) => {
    event.preventDefault();
    const trimmedName = name.trim();
    const trimmedWorkspace = workspaceName.trim();
    if (!trimmedName || Array.from(trimmedName).length > 32 || /[\u0000-\u001F\u007F]/.test(trimmedName)) {
      setFeedback({ kind: 'error', text: 'أدخل اسمًا صالحًا من 1 إلى 32 حرفًا.' });
      return;
    }
    if (!trimmedWorkspace || Array.from(trimmedWorkspace).length > 40) {
      setFeedback({ kind: 'error', text: 'أدخل اسم مساحة عمل من 1 إلى 40 حرفًا.' });
      return;
    }
    const ok = saveSettings({ name: trimmedName, workspaceName: trimmedWorkspace, preferences: { ...state.preferences, localAlerts, projectNotifications, taskNotifications } });
    if (!ok) { setFeedback({ kind: 'error', text: 'تعذر حفظ الإعدادات. تحقّق من مساحة تخزين المتصفح وحاول مجددًا.' }); return; }
    setFeedback(null);
    setSaved(true);
    window.setTimeout(() => setSaved(false), 2800);
  };

  const exportBackup = async () => {
    setBusy(true);
    setFeedback(null);
    try {
      const result = await buildWorkspaceBackup(state);
      const url = URL.createObjectURL(result.blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = result.filename;
      link.click();
      window.setTimeout(() => URL.revokeObjectURL(url), 30_000);
      setFeedback({ kind: result.missingFiles.length ? 'info' : 'success', text: result.missingFiles.length ? `تم إنشاء النسخة، لكن تعذر تضمين ${result.missingFiles.length} ملفًا محليًا لم يعد متاحًا.` : `تم تنزيل نسخة NEXO الاحتياطية: ${result.filename}` });
    } catch (error) {
      setFeedback({ kind: 'error', text: error instanceof Error ? error.message : 'تعذر إنشاء النسخة الاحتياطية.' });
    } finally { setBusy(false); }
  };

  const prepareImport = async (file?: File) => {
    if (!file) return;
    setBusy(true);
    setFeedback(null);
    try {
      const parsed = await parseWorkspaceBackup(file);
      setPendingImport(parsed);
    } catch (error) {
      setFeedback({ kind: 'error', text: error instanceof Error ? error.message : 'تعذر قراءة النسخة الاحتياطية.' });
    } finally {
      setBusy(false);
      if (backupInputRef.current) backupInputRef.current.value = '';
    }
  };

  const confirmImport = async () => {
    if (!pendingImport) return;
    setBusy(true);
    const ok = await replaceWorkspace(pendingImport.workspace, pendingImport.blobs);
    if (ok) {
      const lostFiles = pendingImport.missingFiles.length;
      setFeedback({ kind: lostFiles ? 'info' : 'success', text: lostFiles ? `تمت الاستعادة. ${lostFiles} ملفًا لم يتضمن محتواه الأرشيف، وبقيت بياناته الوصفية فقط.` : 'تمت استعادة مساحة NEXO وملفاتها المحلية بنجاح.' });
    } else {
      setFeedback({ kind: 'error', text: 'تعذرت الاستعادة؛ لم تُعتمد التغييرات على مساحة العمل.' });
    }
    setBusy(false);
    setPendingImport(null);
  };

  return <main className="page-content"><PageHeader eyebrow="تخصيص مساحة العمل" title="الإعدادات" description="اجعل NEXO أقرب إلى الطريقة التي تعمل بها." />
    <form onSubmit={submit} className="settings-layout" noValidate>
      <SectionCard className="settings-card"><SectionHeading title="الملف الشخصي" description="الاسم الذي يظهر في مساحة العمل" /><div className="settings-profile-preview"><span className="avatar avatar-large">{name.trim().slice(0, 1) || 'ن'}</span><span><strong>{name || 'اسمك'}</strong><small>اسم محلي لهذا الجهاز</small></span><Link to="/app/profile" className="subtle-link">عرض الملف الشخصي <ChevronLeft size={14} /></Link></div>
        <div className="settings-field-grid"><label htmlFor="settings-name">الاسم<input id="settings-name" value={name} onChange={(event) => setLocalName(event.target.value)} maxLength={32} /></label><label htmlFor="settings-workspace-name">اسم مساحة العمل<input id="settings-workspace-name" value={workspaceName} onChange={(event) => setLocalWorkspaceName(event.target.value)} maxLength={40} /></label></div>
        <div className="field-footnote"><Info size={14} /> لا نطلب بريدًا إلكترونيًا أو ننشئ حسابًا. الاسم محفوظ في متصفحك فقط.</div>
      </SectionCard>
      <SectionCard className="settings-card"><SectionHeading title="تفضيلات التنبيهات" description="اختيارات محلية داخل NEXO؛ لا تُرسل بريدًا أو إشعارات خارجية." /><div className="settings-option-list">
        <div className="settings-option"><span className="option-icon"><Bell size={17} /></span><span className="option-copy"><strong>تنبيهات داخل الواجهة</strong><small>تفضيل محلي فقط؛ لا توجد خدمة بريد أو إشعارات فعلية.</small></span><Toggle checked={localAlerts} onChange={setLocalAlerts} label="تنبيهات داخل الواجهة" /></div>
        <div className="settings-option"><span className="option-icon"><FolderPlusIcon /></span><span className="option-copy"><strong>تحديثات المشاريع</strong><small>تفضيل لعرض إجراءات المشاريع ضمن سجل النشاط.</small></span><Toggle checked={projectNotifications} onChange={setProjectNotifications} label="تحديثات المشاريع" /></div>
        <div className="settings-option"><span className="option-icon"><Check size={17} /></span><span className="option-copy"><strong>تذكيرات المهام</strong><small>تفضيل محلي لعرض معلومات المهام داخل المساحة.</small></span><Toggle checked={taskNotifications} onChange={setTaskNotifications} label="تذكيرات المهام" /></div>
      </div></SectionCard>
      <SectionCard className="settings-card"><SectionHeading title="المظهر" description="اختر النمط الذي يناسب بيئة عملك" /><div className="theme-choice-grid"><button type="button" onClick={() => changeTheme('light')} className={`theme-choice theme-choice-light${state.preferences.theme === 'light' ? ' selected' : ''}`}><span className="theme-preview light-preview"><i /><i /><i /></span><span><Sun size={16} /> فاتح</span>{state.preferences.theme === 'light' && <Check size={16} className="theme-selected-check" />}</button><button type="button" onClick={() => changeTheme('dark')} className={`theme-choice theme-choice-dark${state.preferences.theme === 'dark' ? ' selected' : ''}`}><span className="theme-preview dark-preview"><i /><i /><i /></span><span><Moon size={16} /> داكن</span>{state.preferences.theme === 'dark' && <Check size={16} className="theme-selected-check" />}</button><span className="theme-preview-note"><Monitor size={14} /> يُحفظ اختيارك على هذا الجهاز.</span></div></SectionCard>
      <div className="settings-save-bar"><span>{feedback?.kind === 'error' ? <span className="settings-inline-error" role="alert">{feedback.text}</span> : saved ? <><Check size={16} /> تم حفظ التغييرات على هذا الجهاز.</> : 'التغييرات محفوظة محليًا بعد التأكيد.'}</span><button type="submit" className="button button-primary">حفظ التغييرات <ArrowLeft size={15} /></button></div>
    </form>

    <SectionCard className="settings-card backup-card"><SectionHeading title="النسخ الاحتياطي والاستعادة" description="احتفظ بنسخة قابلة للنقل من بياناتك المحلية وملفاتها." /><div className="backup-actions"><button type="button" className="button button-primary" disabled={busy} onClick={() => void exportBackup()}><Download size={16} />{busy ? 'جارٍ تجهيز النسخة…' : 'تصدير نسخة احتياطية'}</button><button type="button" className="button button-outline" disabled={busy} onClick={() => backupInputRef.current?.click()}><Upload size={16} />استيراد نسخة احتياطية</button><input ref={backupInputRef} type="file" accept=".zip,application/zip" className="sr-only" onChange={(event) => void prepareImport(event.target.files?.[0])} /></div><p className="backup-explanation">يحتوي ملف ZIP على إعدادات NEXO وبيانات المشاريع والمهام والنشاط، ويضم الملفات الفعلية الموجودة محليًا. خزّنه خارج هذا الجهاز؛ ملفاتك لا تُرفع إلى خادم.</p>
      {feedback && <div className={`backup-feedback feedback-${feedback.kind}`} role={feedback.kind === 'error' ? 'alert' : 'status'}>{feedback.text}</div>}
      {pendingImport && <div className="backup-pending" role="status"><ArchiveRestore size={17} /><span>تم التحقق من النسخة. تحتوي على {pendingImport.workspace.projects.length} مشروعًا و{pendingImport.workspace.tasks.length} مهمة و{pendingImport.workspace.files.length} ملف.</span><button type="button" className="button button-danger button-sm" onClick={() => setPendingImport(null)}>إلغاء الاستيراد</button></div>}
    </SectionCard>

    <SectionCard className="settings-card privacy-card"><SectionHeading title="بياناتك محلية" description="معلومة مهمة عن مكان حفظ مساحة العمل" /><div className="privacy-message"><span className="privacy-icon"><ShieldCheck size={18} /></span><p>بياناتك محلية. NEXO لا يرفع مشاريعك وملفاتك إلى خادم في هذه النسخة. إذا مسحت بيانات الموقع أو المتصفح، قد تفقد مساحة العمل. استخدم النسخ الاحتياطي للحماية.</p></div></SectionCard>

    <SectionCard className="settings-card"><SectionHeading title="المساعدة" description="روابط سريعة حول مساحة NEXO" /><Link className="subtle-link" to="/app/help">الأسئلة الشائعة عن البيانات المحلية <ChevronLeft size={14} /></Link></SectionCard>
    {pendingImport && <ConfirmDialog title="استبدال مساحة العمل الحالية؟" description={`سيحل الملف المستورد مكان بياناتك الحالية بالكامل، بما فيها المشاريع (${state.projects.length}) والمهام (${state.tasks.length}) والملفات (${state.files.length}) والإعدادات والنشاط. ستُستبدل بمحتويات النسخة المحددة. لن يتغير شيء إذا ألغيت.`} confirmLabel="استبدال واستعادة النسخة" onConfirm={confirmImport} onClose={() => setPendingImport(null)} busy={busy} />}
  </main>;
}

function FolderPlusIcon() { return <span className="folder-plus-symbol" aria-hidden="true">+</span>; }

export function ProfilePage() {
  const { state } = useWorkspace();
  return <main className="page-content"><PageHeader eyebrow="مساحة العمل" title="الملف الشخصي" description="تعريف محلي بسيط يساعد NEXO على مخاطبتك بالاسم." />
    <SectionCard className="profile-card"><div className="profile-cover"><span className="profile-cover-line" /><span className="profile-cover-glow" /></div><div className="profile-details"><span className="avatar avatar-profile">{state.name.slice(0, 1) || 'ن'}</span><div className="profile-name-block"><h2>{state.name}</h2><p>عضو في {state.workspaceName}</p></div><Link className="button button-outline button-sm" to="/welcome">تغيير الاسم</Link></div><div className="profile-data-grid"><div><span>الاسم</span><strong>{state.name}</strong></div><div><span>مساحة العمل</span><strong>{state.workspaceName}</strong></div><div><span>طريقة الحفظ</span><strong>على هذا الجهاز</strong></div></div><div className="profile-notice"><Info size={15} /><span>لا يوجد حساب أو تسجيل دخول؛ بياناتك تبقى في تخزين هذا المتصفح.</span></div></SectionCard>
  </main>;
}

export function HelpPage() {
  const questions = [
    ['أين تُحفظ بياناتي؟', 'في التخزين المحلي للمتصفح على هذا الجهاز. لا تُرسل إلى خادم ولا تتزامن تلقائيًا مع أجهزة أخرى.'],
    ['هل أحتاج إلى حساب؟', 'لا. اكتب اسمك فقط لبدء استخدام المساحة. لا يوجد تسجيل دخول أو كلمة مرور.'],
    ['هل أستطيع عمل نسخة احتياطية؟', 'نعم. من الإعدادات صدّر نسخة NEXO واحفظها في مكان مستقل؛ يمكنك استيرادها لاحقًا بعد تأكيد استبدال المساحة الحالية.'],
    ['هل أستطيع رفع ملف؟', 'نعم، تختار ملفًا من جهازك ويُحفظ داخل تخزين المتصفح. الحد الأقصى للملف 20 ميغابايت.'],
    ['ماذا يحدث إذا مسحت بيانات الموقع؟', 'قد يؤدي مسح بيانات المتصفح أو تخزين الموقع إلى حذف بيانات مساحة NEXO وملفاتها المحلية. استخدم النسخ الاحتياطي للحماية.'],
  ];
  return <main className="page-content"><PageHeader eyebrow="مركز المساعدة" title="كيف نساعدك؟" description="إجابات سريعة عن استخدام مساحة NEXO." />
    <div className="help-intro-card"><span className="help-intro-icon"><CircleHelp size={22} /></span><div><strong>مساحتك على هذا الجهاز</strong><p>بما أن NEXO يعمل دون تسجيل دخول، فإن البيانات لا تتزامن ولا تُشارك بين الأجهزة.</p></div></div>
    <SectionCard className="faq-card"><SectionHeading title="أسئلة شائعة" description="معلومات بسيطة لتبدأ بثقة" />{questions.map(([question, answer]) => <details className="faq-item" key={question}><summary>{question}<ChevronLeft size={16} /></summary><p>{answer}</p></details>)}</SectionCard>
  </main>;
}
