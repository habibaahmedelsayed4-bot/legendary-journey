import { useEffect, useState } from 'react';
import { Download, X } from 'lucide-react';

interface InstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

function isAppInstalled(): boolean {
  return window.matchMedia('(display-mode: standalone)').matches
    || (navigator as Navigator & { standalone?: boolean }).standalone === true;
}

export function InstallAppButton() {
  const [deferredPrompt, setDeferredPrompt] = useState<InstallPromptEvent | null>(null);
  const [installed, setInstalled] = useState(isAppInstalled);
  const [showInstructions, setShowInstructions] = useState(false);
  const isAppleMobile = /iPhone|iPad|iPod/i.test(navigator.userAgent);

  useEffect(() => {
    const capturePrompt = (event: Event) => {
      event.preventDefault();
      setDeferredPrompt(event as InstallPromptEvent);
    };
    const markInstalled = () => {
      setInstalled(true);
      setShowInstructions(false);
      setDeferredPrompt(null);
    };
    window.addEventListener('beforeinstallprompt', capturePrompt);
    window.addEventListener('appinstalled', markInstalled);
    return () => {
      window.removeEventListener('beforeinstallprompt', capturePrompt);
      window.removeEventListener('appinstalled', markInstalled);
    };
  }, []);

  const install = async () => {
    if (!deferredPrompt) {
      setShowInstructions(true);
      return;
    }
    await deferredPrompt.prompt();
    const choice = await deferredPrompt.userChoice;
    if (choice.outcome === 'accepted') setInstalled(true);
    setDeferredPrompt(null);
  };

  if (installed) return null;
  return <>
    <button className="install-app-button" type="button" onClick={() => { void install(); }}>
      <Download size={15} /><span>تثبيت NEXO</span>
    </button>
    {showInstructions && <div className="install-dialog-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setShowInstructions(false); }}>
      <section className="install-dialog" role="dialog" aria-modal="true" aria-labelledby="install-dialog-title">
        <button className="install-dialog-close" type="button" onClick={() => setShowInstructions(false)} aria-label="إغلاق"><X size={17} /></button>
        <span className="install-dialog-icon"><Download size={19} /></span>
        <h2 id="install-dialog-title">أضف NEXO إلى جهازك</h2>
        <p>{isAppleMobile
          ? 'في Safari اضغط «مشاركة»، ثم اختر «إضافة إلى الشاشة الرئيسية».'
          : 'من قائمة المتصفح اختر «تثبيت التطبيق» أو «إضافة إلى الشاشة الرئيسية».'}</p>
        <small>سيظهر التطبيق باسم NEXO وبأيقونته الرسمية.</small>
        <button className="button button-primary" type="button" onClick={() => setShowInstructions(false)}>حسنًا</button>
      </section>
    </div>}
  </>;
}
