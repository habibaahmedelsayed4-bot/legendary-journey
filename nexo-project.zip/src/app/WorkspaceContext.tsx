import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { deleteLocalFiles, getLocalFile, loadWorkspace, replaceLocalFiles, saveWorkspace } from '../data/storage';
import { getProjectProgress, getProjectTaskCount, type ActivityItem, type Project, type ProjectStatus, type Task, type TaskStatus, type WorkspaceFile, type WorkspaceState } from '../data/model';

interface WorkspaceContextValue {
  state: WorkspaceState;
  setName: (name: string) => boolean;
  saveSettings: (changes: { name: string; workspaceName: string; preferences: WorkspaceState['preferences'] }) => boolean;
  updateWorkspaceName: (name: string) => boolean;
  updatePreferences: (changes: Partial<WorkspaceState['preferences']>) => void;
  addProject: (project: Omit<Project, 'id' | 'updatedAt' | 'tasksCount' | 'color' | 'archived'>) => void;
  updateProject: (id: string, changes: Partial<Pick<Project, 'name' | 'description' | 'status' | 'archived'>>) => void;
  deleteProject: (id: string) => Promise<boolean>;
  addTask: (task: Omit<Task, 'id'>) => void;
  updateTask: (id: string, changes: Partial<Pick<Task, 'name' | 'projectId' | 'priority' | 'dueDate' | 'status'>>) => void;
  updateTaskStatus: (id: string, status: TaskStatus) => void;
  deleteTask: (id: string) => void;
  addFile: (file: WorkspaceFile) => boolean;
  updateFile: (id: string, changes: Partial<Pick<WorkspaceFile, 'name' | 'projectId'>>) => void;
  deleteFile: (id: string) => Promise<boolean>;
  addActivity: (activity: Omit<ActivityItem, 'id' | 'createdAt'>) => void;
  replaceWorkspace: (workspace: WorkspaceState, blobs: Map<string, Blob>) => Promise<boolean>;
}

const WorkspaceContext = createContext<WorkspaceContextValue | null>(null);

function makeId(prefix: string) {
  return `${prefix}-${crypto.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`}`;
}

function syncProjectProgress(projects: Project[], tasks: Task[]): Project[] {
  return projects.map((project) => ({
    ...project,
    tasksCount: getProjectTaskCount(project.id, tasks),
    progress: getProjectProgress(project.id, tasks),
  }));
}

function recordActivity(current: WorkspaceState, activity: Omit<ActivityItem, 'id' | 'createdAt'>): WorkspaceState {
  const activities: ActivityItem[] = [{ ...activity, id: makeId('activity'), createdAt: new Date().toISOString() }, ...current.activities];
  return { ...current, activities, metrics: { ...current.metrics, recentActivity: activities.length } };
}

function setActivityForTasks(current: WorkspaceState, oldTask: Task, nextTasks: Task[], title: string, description: string): WorkspaceState {
  const touchedProjectIds = new Set([oldTask.projectId, nextTasks.find((task) => task.id === oldTask.id)?.projectId].filter((id): id is string => Boolean(id)));
  const timestamp = new Date().toISOString();
  const projects = syncProjectProgress(current.projects.map((project) => touchedProjectIds.has(project.id) ? { ...project, updatedAt: timestamp } : project), nextTasks);
  const next = {
    ...current,
    tasks: nextTasks,
    projects,
    metrics: { ...current.metrics, completedTasks: nextTasks.filter((task) => task.status === 'مكتملة').length },
  };
  return recordActivity(next, { title, description, kind: 'task', projectId: oldTask.projectId });
}

export function WorkspaceProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<WorkspaceState>(() => loadWorkspace());

  useEffect(() => {
    saveWorkspace(state);
    document.documentElement.dataset.theme = state.preferences.theme;
  }, [state]);

  const value = useMemo<WorkspaceContextValue>(() => ({
    state,
    setName: (name) => {
      const trimmedName = name.trim();
      if (!trimmedName || Array.from(trimmedName).length > 32 || /[\u0000-\u001F\u007F]/.test(trimmedName)) return false;
      const base = { ...state, name: trimmedName };
      const next = state.name && state.name !== trimmedName
        ? recordActivity(base, { title: 'تم تحديث الاسم', description: `الاسم الجديد: ${trimmedName}`, kind: 'settings' })
        : base;
      if (!saveWorkspace(next)) return false;
      setState(next);
      return true;
    },
    saveSettings: (changes) => {
      const name = changes.name.trim();
      const workspaceName = changes.workspaceName.trim();
      if (!name || Array.from(name).length > 32 || /[\u0000-\u001F\u007F]/.test(name) || !workspaceName || Array.from(workspaceName).length > 40) return false;
      const preferences = { ...state.preferences, ...changes.preferences };
      const changed = name !== state.name || workspaceName !== state.workspaceName || preferences.theme !== state.preferences.theme || preferences.localAlerts !== state.preferences.localAlerts || preferences.projectNotifications !== state.preferences.projectNotifications || preferences.taskNotifications !== state.preferences.taskNotifications;
      const base = { ...state, name, workspaceName, preferences };
      const next = changed ? recordActivity(base, { title: 'تم حفظ تفضيلات المساحة', description: 'تم تحديث الاسم أو إعدادات مساحة العمل والتنبيهات المحلية.', kind: 'settings' }) : base;
      if (!saveWorkspace(next)) return false;
      setState(next);
      return true;
    },
    updateWorkspaceName: (workspaceName) => {
      const trimmed = workspaceName.trim();
      if (!trimmed) return false;
      const next = { ...state, workspaceName: trimmed };
      if (!saveWorkspace(next)) return false;
      setState(next);
      return true;
    },
    updatePreferences: (changes) => setState((current) => ({ ...current, preferences: { ...current.preferences, ...changes } })),
    addProject: (project) => setState((current) => {
      const id = makeId('project');
      const timestamp = new Date().toISOString();
      const projects = syncProjectProgress([
        { ...project, id, updatedAt: timestamp, tasksCount: 0, color: '#6d91ff', archived: false, progress: 0 },
        ...current.projects,
      ], current.tasks);
      return recordActivity({ ...current, projects }, { title: 'تم إنشاء مشروع جديد', description: project.name, kind: 'project', projectId: id });
    }),
    updateProject: (id, changes) => setState((current) => {
      const existing = current.projects.find((project) => project.id === id);
      if (!existing) return current;
      const safeChanges = {
        ...changes,
        ...(typeof changes.name === 'string' ? { name: changes.name.trim() } : {}),
        ...(typeof changes.description === 'string' ? { description: changes.description.trim() } : {}),
      };
      const changed = { ...existing, ...safeChanges };
      if (changed.name === existing.name && changed.description === existing.description && changed.status === existing.status && changed.archived === existing.archived) return current;
      const timestamp = new Date().toISOString();
      const projects = syncProjectProgress(current.projects.map((project) => project.id === id ? { ...changed, updatedAt: timestamp } : project), current.tasks);
      const title = changed.archived !== existing.archived ? (changed.archived ? 'تمت أرشفة مشروع' : 'تمت استعادة مشروع من الأرشيف') : 'تم تحديث مشروع';
      const description = changed.name !== existing.name ? `${existing.name} ← ${changed.name}` : changed.status !== existing.status ? `${changed.name} — ${changed.status}` : changed.description !== existing.description ? `تم تعديل وصف ${changed.name}` : changed.name;
      return recordActivity({ ...current, projects }, { title, description, kind: 'project', projectId: id });
    }),
    deleteProject: async (id) => {
      const project = state.projects.find((item) => item.id === id);
      if (!project) return false;
      const files = state.files.filter((file) => file.projectId === id);
      const next = recordActivity({
        ...state,
        projects: state.projects.filter((item) => item.id !== id),
        tasks: state.tasks.filter((task) => task.projectId !== id),
        files: state.files.filter((file) => file.projectId !== id),
        activities: state.activities.filter((activity) => activity.projectId !== id),
        metrics: {
          completedTasks: state.tasks.filter((task) => task.projectId !== id && task.status === 'مكتملة').length,
          fileCount: state.files.filter((file) => file.projectId !== id).length,
          recentActivity: state.activities.filter((activity) => activity.projectId !== id).length,
        },
      }, { title: 'تم حذف مشروع', description: project.name, kind: 'project' });
      if (!saveWorkspace(next)) return false;
      try {
        await deleteLocalFiles(files.filter((file) => file.localBlob).map((file) => file.id));
      } catch {
        saveWorkspace(state);
        window.dispatchEvent(new CustomEvent('nexo:storage-error'));
        return false;
      }
      setState(next);
      return true;
    },
    addTask: (task) => setState((current) => {
      if (!current.projects.some((project) => project.id === task.projectId)) return current;
      const newTask = { ...task, name: task.name.trim(), dueDate: task.dueDate || '', id: makeId('task') };
      const tasks = [newTask, ...current.tasks];
      const timestamp = new Date().toISOString();
      const updatedProjects = current.projects.map((project) => project.id === task.projectId ? { ...project, updatedAt: timestamp } : project);
      const updated = {
        ...current,
        tasks,
        projects: syncProjectProgress(updatedProjects, tasks),
        metrics: { ...current.metrics, completedTasks: tasks.filter((item) => item.status === 'مكتملة').length },
      };
      return recordActivity(updated, { title: 'تمت إضافة مهمة', description: `${newTask.name} — ${current.projects.find((item) => item.id === task.projectId)?.name ?? ''}`.trim(), kind: 'task', projectId: task.projectId });
    }),
    updateTask: (id, changes) => setState((current) => {
      const oldTask = current.tasks.find((task) => task.id === id);
      if (!oldTask) return current;
      const safeChanges = { ...changes, ...(typeof changes.name === 'string' ? { name: changes.name.trim() } : {}), ...(changes.dueDate === undefined ? {} : { dueDate: changes.dueDate || '' }) };
      if (safeChanges.projectId && !current.projects.some((project) => project.id === safeChanges.projectId)) return current;
      const tasks = current.tasks.map((task) => task.id === id ? { ...task, ...safeChanges } : task);
      return setActivityForTasks(current, oldTask, tasks, 'تم تعديل مهمة', `${oldTask.name} — ${tasks.find((task) => task.id === id)?.name ?? oldTask.name}`);
    }),
    updateTaskStatus: (id, status) => setState((current) => {
      const oldTask = current.tasks.find((task) => task.id === id);
      if (!oldTask || oldTask.status === status) return current;
      const tasks = current.tasks.map((task) => task.id === id ? { ...task, status } : task);
      return setActivityForTasks(current, oldTask, tasks, status === 'مكتملة' ? 'تم إكمال مهمة' : 'تم تحديث حالة مهمة', oldTask.name);
    }),
    deleteTask: (id) => setState((current) => {
      const task = current.tasks.find((item) => item.id === id);
      if (!task) return current;
      const tasks = current.tasks.filter((item) => item.id !== id);
      const timestamp = new Date().toISOString();
      const projects = syncProjectProgress(current.projects.map((project) => project.id === task.projectId ? { ...project, updatedAt: timestamp } : project), tasks);
      return recordActivity({ ...current, tasks, projects, metrics: { ...current.metrics, completedTasks: tasks.filter((item) => item.status === 'مكتملة').length } }, { title: 'تم حذف مهمة', description: task.name, kind: 'task', projectId: task.projectId });
    }),
    addFile: (file) => {
      const files = [file, ...state.files];
      const next = recordActivity({ ...state, files, metrics: { ...state.metrics, fileCount: files.length } }, { title: 'تم حفظ ملف على هذا الجهاز', description: file.name, kind: 'file', ...(file.projectId ? { projectId: file.projectId } : {}) });
      if (!saveWorkspace(next)) return false;
      setState(next);
      return true;
    },
    updateFile: (id, changes) => setState((current) => {
      const file = current.files.find((item) => item.id === id);
      if (!file) return current;
      const updatedFile = { ...file, ...changes, name: changes.name?.trim() || file.name };
      if (updatedFile.name === file.name && updatedFile.projectId === file.projectId) return current;
      return recordActivity({ ...current, files: current.files.map((item) => item.id === id ? updatedFile : item) }, { title: 'تم تحديث ملف', description: updatedFile.name, kind: 'file', ...(updatedFile.projectId ? { projectId: updatedFile.projectId } : {}) });
    }),
    deleteFile: async (id) => {
      const file = state.files.find((item) => item.id === id);
      if (!file) return false;
      const remaining = state.files.filter((item) => item.id !== id);
      const next = recordActivity({ ...state, files: remaining, metrics: { ...state.metrics, fileCount: remaining.length } }, { title: 'تم حذف ملف', description: file.name, kind: 'file', ...(file.projectId ? { projectId: file.projectId } : {}) });
      if (!saveWorkspace(next)) return false;
      try {
        if (file.localBlob) await deleteLocalFiles([file.id]);
      } catch {
        saveWorkspace(state);
        window.dispatchEvent(new CustomEvent('nexo:storage-error'));
        return false;
      }
      setState(next);
      return true;
    },
    addActivity: (activity) => setState((current) => recordActivity(current, activity)),
    replaceWorkspace: async (workspace, blobs) => {
      const previousBlobs = new Map<string, Blob>();
      for (const file of state.files.filter((item) => item.localBlob)) {
        const blob = await getLocalFile(file.id);
        if (blob) previousBlobs.set(file.id, blob);
      }
      try {
        await replaceLocalFiles(blobs);
        if (!saveWorkspace(workspace)) {
          await replaceLocalFiles(previousBlobs);
          return false;
        }
        setState(workspace);
        return true;
      } catch {
        try { await replaceLocalFiles(previousBlobs); } catch { /* keep the surfaced restore error */ }
        window.dispatchEvent(new CustomEvent('nexo:storage-error'));
        return false;
      }
    },
  }), [state]);

  return <WorkspaceContext.Provider value={value}>{children}</WorkspaceContext.Provider>;
}

export function useWorkspace() {
  const value = useContext(WorkspaceContext);
  if (!value) throw new Error('useWorkspace must be used within WorkspaceProvider');
  return value;
}

export function statusTone(status: ProjectStatus | TaskStatus) {
  if (status === 'مكتمل' || status === 'مكتملة') return 'success';
  if (status === 'قيد المراجعة') return 'violet';
  if (status === 'قيد التنفيذ') return 'blue';
  return 'muted';
}
