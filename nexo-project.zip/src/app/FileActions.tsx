import { useEffect, useId, useRef, useState } from 'react';
import { Download, Eye, Link2, MoreHorizontal, Pencil, Trash2, X } from 'lucide-react';
import { ConfirmDialog } from './ConfirmDialog';
import { Modal } from './Modal';
import { useWorkspace } from './WorkspaceContext';
import { formatBytes, getLocalFile } from '../data/storage';
import { formatDate } from '../data/format';
import type { WorkspaceFile } from '../data/model';

type FilePreview = { kind: 'image'; url: string } | { kind: 'text'; text: string };
type FilePanel = 'rename' | 'link' | 'preview' | null;
const IMAGE_TYPES = new Set(['PNG', 'JPG', 'JPEG', 'GIF', 'WEBP', 'AVIF']);
const TEXT_TYPES = new Set(['TXT', 'MD', 'CSV']);
const MAX_TEXT_PREVIEW = 1024 * 1024;

function clickDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  anchor.style.display = 'none';
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 30_000);
}

export function FileActions({ file, compact = false }: { file: WorkspaceFile; compact?: boolean }) {
  const { state, updateFile, deleteFile } = useWorkspace();
  const [panel, setPanel] = useState<FilePanel>(null);
  const [preview, setPreview] = useState<FilePreview | null>(null);
  const [rename, setRename] = useState(file.name);
  const [projectId, setProjectId] = useState(file.projectId ?? '');
  const [error, setError] = useState('');
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [busy, setBusy] = useState(false);
  const menuRef = useRef<HTMLDetailsElement>(null);
  const titleId = useId();
  const extension = file.type.toUpperCase();
  const canPreview = file.localBlob && (IMAGE_TYPES.has(extension) || (TEXT_TYPES.has(extension) && file.size <= MAX_TEXT_PREVIEW));
  const linkedProject = state.projects.find((project) => project.id === file.projectId);

  useEffect(() => () => { if (preview?.kind === 'image') URL.revokeObjectURL(preview.url); }, [preview]);

  const closeMenu = () => { if (menuRef.current) menuRef.current.open = false; };
  const download = async () => {
    closeMenu();
    setError('');
    if (!file.localBlob) { setError('محتوى هذا الملف غير متاح في تخزين المتصفح.'); return; }
    try {
      const blob = await getLocalFile(file.id);
      if (!blob) { setError('لم يعد الملف موجودًا في تخزين المتصفح.'); return; }
      clickDownload(blob, file.name);
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'تعذر تنزيل الملف.'); }
  };
  const openPreview = async () => {
    closeMenu();
    setError('');
    try {
      const blob = await getLocalFile(file.id);
      if (!blob) { setError('لم يعد الملف موجودًا في تخزين المتصفح.'); return; }
      if (IMAGE_TYPES.has(extension)) {
        setPreview({ kind: 'image', url: URL.createObjectURL(blob) });
        setPanel('preview');
      } else if (TEXT_TYPES.has(extension) && blob.size <= MAX_TEXT_PREVIEW) {
        setPreview({ kind: 'text', text: await blob.text() });
        setPanel('preview');
      }
    } catch (reason) { setError(reason instanceof Error ? reason.message : 'تعذرت معاينة الملف.'); }
  };
  const saveRename = () => {
    const value = rename.trim();
    if (!value || value.length > 180 || /[\u0000-\u001F\u007F]/.test(value)) { setError('أدخل اسم ملف صالحًا من 1 إلى 180 حرفًا.'); return; }
    updateFile(file.id, { name: value });
    setPanel(null);
    setError('');
  };
  const saveProjectLink = () => {
    updateFile(file.id, projectId ? { projectId } : { projectId: undefined });
    setPanel(null);
    setError('');
  };
  const removeFile = async () => {
    setBusy(true);
    setError('');
    const removed = await deleteFile(file.id);
    setBusy(false);
    if (removed) setConfirmDelete(false);
    else setError('تعذر حذف الملف من بيانات المساحة أو IndexedDB. لم يُعتمد الحذف.');
  };

  return <div className={`file-actions${compact ? ' file-actions-compact' : ''}`}>
    <details className="entity-actions-menu" ref={menuRef}>
      <summary className="entity-actions-trigger" aria-label={`إجراءات الملف ${file.name}`} title="إجراءات الملف"><MoreHorizontal size={17} /></summary>
      <div className="entity-actions-panel" role="group" aria-label={`إجراءات ${file.name}`}>
        {canPreview && <button type="button" onClick={() => void openPreview()}><Eye size={14} />معاينة الملف</button>}
        <button type="button" disabled={!file.localBlob} onClick={() => void download()}><Download size={14} />تنزيل الملف</button>
        <button type="button" onClick={() => { setRename(file.name); setError(''); setPanel('rename'); closeMenu(); }}><Pencil size={14} />إعادة تسمية</button>
        <button type="button" onClick={() => { setProjectId(file.projectId ?? ''); setError(''); setPanel('link'); closeMenu(); }}><Link2 size={14} />{linkedProject ? 'تغيير المشروع المرتبط' : 'ربط بمشروع'}</button>
        <button type="button" className="danger-action" onClick={() => { setConfirmDelete(true); closeMenu(); }}><Trash2 size={14} />حذف الملف</button>
      </div>
    </details>
    {error && <span className="file-action-error" role="status">{error}</span>}

    {panel === 'rename' && <Modal labelledBy={titleId} onClose={() => setPanel(null)}>
      <button type="button" className="modal-close" onClick={() => setPanel(null)} aria-label="إغلاق النافذة"><X size={16} /></button>
      <span className="page-eyebrow">ملفات مساحة العمل</span><h2 id={titleId}>إعادة تسمية الملف</h2><p>سيبقى محتوى الملف نفسه محفوظًا على هذا الجهاز.</p>
      <form className="form-stack" onSubmit={(event) => { event.preventDefault(); saveRename(); }} noValidate><label htmlFor={`rename-${file.id}`}>اسم الملف<input id={`rename-${file.id}`} data-autofocus maxLength={180} value={rename} onChange={(event) => { setRename(event.target.value); setError(''); }} aria-invalid={Boolean(error)} aria-describedby={error ? `rename-error-${file.id}` : undefined} /></label>{error && <span className="field-error" id={`rename-error-${file.id}`} role="alert">{error}</span>}<div className="modal-actions"><button className="button button-primary" type="submit">حفظ الاسم</button><button className="button button-outline" type="button" onClick={() => setPanel(null)}>إلغاء</button></div></form>
    </Modal>}

    {panel === 'link' && <Modal labelledBy={titleId} onClose={() => setPanel(null)}>
      <button type="button" className="modal-close" onClick={() => setPanel(null)} aria-label="إغلاق النافذة"><X size={16} /></button>
      <span className="page-eyebrow">تنظيم الملفات</span><h2 id={titleId}>{linkedProject ? 'تغيير المشروع المرتبط' : 'ربط الملف بمشروع'}</h2><p>اختر المشروع الذي ينتمي إليه الملف، أو اتركه في المكتبة العامة.</p>
      <form className="form-stack" onSubmit={(event) => { event.preventDefault(); saveProjectLink(); }}><label htmlFor={`file-project-${file.id}`}>المشروع<select id={`file-project-${file.id}`} data-autofocus value={projectId} onChange={(event) => setProjectId(event.target.value)}><option value="">المكتبة العامة — دون مشروع</option>{state.projects.map((project) => <option key={project.id} value={project.id}>{project.name}{project.archived ? ' — مؤرشف' : ''}</option>)}</select></label><div className="modal-actions"><button className="button button-primary" type="submit">حفظ الربط</button><button className="button button-outline" type="button" onClick={() => setPanel(null)}>إلغاء</button></div></form>
    </Modal>}

    {panel === 'preview' && preview && <Modal labelledBy={titleId} className="file-preview-modal" onClose={() => { setPanel(null); setPreview(null); }}>
      <button type="button" className="modal-close" onClick={() => { setPanel(null); setPreview(null); }} aria-label="إغلاق المعاينة"><X size={16} /></button>
      <span className="page-eyebrow">معاينة محلية · {extension}</span><h2 id={titleId} className="file-preview-title">{file.name}</h2><p>{formatBytes(file.size)} · {formatDate(file.date)}{linkedProject ? ` · ${linkedProject.name}` : ''}</p>
      {preview.kind === 'image' ? <img className="file-image-preview" src={preview.url} alt={`معاينة ${file.name}`} /> : <pre className="file-text-preview" dir="auto">{preview.text}</pre>}
      <div className="modal-actions"><button type="button" className="button button-primary" onClick={() => void download()}>تنزيل الملف <Download size={15} /></button><button type="button" className="button button-outline" onClick={() => { setPanel(null); setPreview(null); }}>إغلاق</button></div>
    </Modal>}

    {confirmDelete && <ConfirmDialog title="حذف الملف؟" description="هل تريد حذف هذا الملف من هذا الجهاز؟ سيُحذف سجل الملف ومحتواه من IndexedDB إذا كان محفوظًا محليًا." confirmLabel="حذف الملف" busy={busy} onConfirm={removeFile} onClose={() => { if (!busy) setConfirmDelete(false); }} />}
  </div>;
}
