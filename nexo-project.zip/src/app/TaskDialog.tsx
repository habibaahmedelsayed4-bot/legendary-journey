import { useState, type FormEvent } from 'react';
import { ArrowLeft, CirclePlus, FolderKanban } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Modal } from './Modal';
import { useWorkspace } from './WorkspaceContext';
import type { Priority, Task, TaskStatus } from '../data/model';

interface TaskDialogProps {
  task?: Task;
  initialProjectId?: string;
  onClose: () => void;
}

export function TaskDialog({ task, initialProjectId, onClose }: TaskDialogProps) {
  const { state, addTask, updateTask } = useWorkspace();
  const [name, setName] = useState(task?.name ?? '');
  const [projectId, setProjectId] = useState(task?.projectId ?? initialProjectId ?? state.projects.find((project) => !project.archived)?.id ?? '');
  const [priority, setPriority] = useState<Priority>(task?.priority ?? 'متوسطة');
  const [dueDate, setDueDate] = useState(task?.dueDate ?? '');
  const [status, setStatus] = useState<TaskStatus>(task?.status ?? 'لم تبدأ');
  const [error, setError] = useState('');
  const titleId = 'task-dialog-title';
  const selectableProjects = state.projects.filter((project) => !project.archived || project.id === task?.projectId);

  const submit = (event: FormEvent) => {
    event.preventDefault();
    const trimmedName = name.trim();
    if (!trimmedName) { setError('اكتب اسم المهمة للمتابعة.'); return; }
    if (Array.from(trimmedName).length > 120) { setError('اجعل اسم المهمة 120 حرفًا أو أقل.'); return; }
    if (!projectId || !selectableProjects.some((project) => project.id === projectId)) { setError('اختر مشروعًا نشطًا حقيقيًا لهذه المهمة.'); return; }
    if (dueDate && Number.isNaN(new Date(`${dueDate}T00:00:00`).getTime())) { setError('اختر تاريخًا صالحًا أو اترك الموعد فارغًا.'); return; }
    if (task) updateTask(task.id, { name: trimmedName, projectId, priority, dueDate, status });
    else addTask({ name: trimmedName, projectId, priority, dueDate, status });
    onClose();
  };

  return <Modal labelledBy={titleId} onClose={onClose}>
    <button className="modal-close" type="button" onClick={onClose} aria-label="إغلاق النافذة"><span>×</span></button>
    <span className="modal-icon"><CirclePlus size={19} /></span>
    <span className="page-eyebrow">{task ? 'تحديث التفاصيل' : 'إضافة إلى قائمتك'}</span>
    <h2 id={titleId}>{task ? 'تعديل المهمة' : 'مهمة جديدة'}</h2>
    {selectableProjects.length === 0 ? <><p>أنشئ مشروعًا أولًا حتى ترتبط المهمة بتقدم واضح.</p><div className="modal-actions"><Link className="button button-primary" to="/app/projects" onClick={onClose}><FolderKanban size={16} />إنشاء مشروع</Link><button className="button button-outline" type="button" onClick={onClose}>إلغاء</button></div></> : <>
      <p>يمكنك ترك تاريخ الاستحقاق فارغًا واختياره لاحقًا.</p>
      <form onSubmit={submit} className="form-stack" noValidate>
        <label htmlFor="task-name">اسم المهمة<input id="task-name" data-autofocus maxLength={120} value={name} onChange={(event) => { setName(event.target.value); setError(''); }} placeholder="مثال: تجهيز مراجعة التصميم" aria-invalid={Boolean(error)} aria-describedby={error ? 'task-form-error' : undefined} /></label>
        <label htmlFor="task-project">المشروع المرتبط<select id="task-project" value={projectId} onChange={(event) => setProjectId(event.target.value)}>{selectableProjects.map((project) => <option key={project.id} value={project.id}>{project.name}{project.archived ? ' — مؤرشف' : ''}</option>)}</select></label>
        <div className="form-row">
          <label htmlFor="task-priority">الأولوية<select id="task-priority" value={priority} onChange={(event) => setPriority(event.target.value as Priority)}><option>منخفضة</option><option>متوسطة</option><option>عالية</option></select></label>
          <label htmlFor="task-due-date">تاريخ الاستحقاق (اختياري)<input id="task-due-date" type="date" value={dueDate} onChange={(event) => setDueDate(event.target.value)} /></label>
        </div>
        {task && <label htmlFor="task-status">الحالة<select id="task-status" value={status} onChange={(event) => setStatus(event.target.value as TaskStatus)}><option>لم تبدأ</option><option>قيد التنفيذ</option><option>مكتملة</option></select></label>}
        {error && <span className="field-error" id="task-form-error" role="alert">{error}</span>}
        <div className="modal-actions"><button className="button button-primary" type="submit">{task ? 'حفظ التغييرات' : 'إضافة المهمة'} <ArrowLeft size={15} /></button><button className="button button-outline" type="button" onClick={onClose}>إلغاء</button></div>
      </form>
    </>}
  </Modal>;
}
