const locale = 'ar-EG-u-ca-gregory-nu-latn';

function asValidDate(value: string | null | undefined): Date | null {
  if (!value) return null;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
}

function arabicNumber(value: number): string {
  return new Intl.NumberFormat(locale, { maximumFractionDigits: 0 }).format(value);
}

export function formatDate(value: string | null | undefined): string {
  const date = asValidDate(value);
  if (!date) return 'تاريخ غير متاح';
  return new Intl.DateTimeFormat(locale, { day: 'numeric', month: 'long', year: 'numeric' }).format(date);
}

export function formatDateTime(value: string | null | undefined): string {
  const date = asValidDate(value);
  if (!date) return 'وقت غير متاح';
  return new Intl.DateTimeFormat(locale, { day: 'numeric', month: 'long', year: 'numeric', hour: 'numeric', minute: '2-digit' }).format(date);
}

export function formatDueDate(value: string | null | undefined): string {
  if (!value) return 'بلا موعد';
  const parts = value.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!parts) return 'موعد غير صالح';
  const date = new Date(Number(parts[1]), Number(parts[2]) - 1, Number(parts[3]), 12);
  if (Number.isNaN(date.getTime())) return 'موعد غير صالح';
  return new Intl.DateTimeFormat(locale, { day: 'numeric', month: 'short', year: 'numeric' }).format(date);
}

function localCalendarDay(date: Date): number {
  return Math.floor(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()) / 86_400_000);
}

export function formatRelativeTime(value: string | null | undefined, now = Date.now()): string {
  const date = asValidDate(value);
  if (!date) return 'وقت غير متاح';
  const seconds = Math.floor((now - date.getTime()) / 1000);
  if (seconds < 0) return formatDateTime(value);
  if (seconds < 60) return 'الآن';
  const minutes = Math.floor(seconds / 60);
  if (minutes === 1) return 'منذ دقيقة';
  if (minutes === 2) return 'منذ دقيقتين';
  if (minutes <= 10) return `منذ ${arabicNumber(minutes)} دقائق`;
  if (minutes < 60) return `منذ ${arabicNumber(minutes)} دقيقة`;
  const hours = Math.floor(minutes / 60);
  if (hours === 1) return 'منذ ساعة';
  if (hours === 2) return 'منذ ساعتين';
  if (hours <= 10) return `منذ ${arabicNumber(hours)} ساعات`;
  if (hours < 24) return `منذ ${arabicNumber(hours)} ساعة`;
  const dayDifference = localCalendarDay(new Date(now)) - localCalendarDay(date);
  if (dayDifference === 1) return 'أمس';
  if (dayDifference === 2) return 'منذ يومين';
  if (dayDifference >= 3 && dayDifference < 7) return `منذ ${arabicNumber(dayDifference)} أيام`;
  return formatDate(value);
}

export function groupActivityDate(value: string | null | undefined, now = Date.now()): string {
  const date = asValidDate(value);
  if (!date) return 'وقت غير متاح';
  const dayDifference = localCalendarDay(new Date(now)) - localCalendarDay(date);
  if (dayDifference <= 0) return 'اليوم';
  if (dayDifference === 1) return 'أمس';
  return formatDate(value);
}

export function localDateKey(date = new Date()): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}
