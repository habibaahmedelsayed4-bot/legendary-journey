import JSZip from 'jszip';
import { getLocalFile, normalizeImportedWorkspace } from './storage';
import { MAX_LOCAL_FILE_BYTES, type WorkspaceState } from './model';

const BACKUP_FORMAT = 'NEXO_LOCAL_WORKSPACE_BACKUP';
const BACKUP_VERSION = 1;
const DOCUMENT_PATH = 'nexo-backup.json';
const ID_PATTERN = /^[a-z0-9_-]{1,128}$/i;

interface BackupDocument {
  format: string;
  version: number;
  exportedAt: string;
  workspace: WorkspaceState;
  blobIds: string[];
}

export interface ParsedBackup {
  workspace: WorkspaceState;
  blobs: Map<string, Blob>;
  missingFiles: string[];
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value && typeof value === 'object' && !Array.isArray(value));
}

function blobPath(id: string): string {
  if (!ID_PATTERN.test(id)) throw new Error('تحتوي النسخة على معرّف ملف غير صالح.');
  return `files/${id}.blob`;
}

export async function buildWorkspaceBackup(state: WorkspaceState): Promise<{ blob: Blob; filename: string; missingFiles: string[] }> {
  const zip = new JSZip();
  const missingFiles: string[] = [];
  const blobIds: string[] = [];
  const files = [] as WorkspaceState['files'];

  for (const file of state.files) {
    if (!file.localBlob) {
      files.push({ ...file });
      continue;
    }
    try {
      const blob = await getLocalFile(file.id);
      if (!blob || blob.size > MAX_LOCAL_FILE_BYTES || blob.size !== file.size) {
        missingFiles.push(file.name);
        files.push({ ...file, localBlob: false });
        continue;
      }
      const path = blobPath(file.id);
      zip.file(path, blob, { binary: true });
      blobIds.push(file.id);
      files.push({ ...file, localBlob: true, size: blob.size });
    } catch {
      missingFiles.push(file.name);
      files.push({ ...file, localBlob: false });
    }
  }

  const workspace: WorkspaceState = { ...state, files };
  const document: BackupDocument = { format: BACKUP_FORMAT, version: BACKUP_VERSION, exportedAt: new Date().toISOString(), workspace, blobIds };
  zip.file(DOCUMENT_PATH, JSON.stringify(document, null, 2));
  const blob = await zip.generateAsync({ type: 'blob', compression: 'DEFLATE', compressionOptions: { level: 4 } });
  const date = new Date();
  const datePart = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
  return { blob, filename: `nexo-backup-${datePart}.zip`, missingFiles };
}

export async function parseWorkspaceBackup(file: File): Promise<ParsedBackup> {
  if (!file.size) throw new Error('الملف فارغ. اختر نسخة NEXO صالحة.');
  let zip: JSZip;
  try {
    zip = await JSZip.loadAsync(file, { checkCRC32: true });
  } catch {
    throw new Error('تعذر قراءة الأرشيف. اختر ملف ZIP أصليًا صادرًا من NEXO.');
  }
  const documentEntry = zip.file(DOCUMENT_PATH);
  if (!documentEntry) throw new Error('لا يوجد ملف بيانات NEXO داخل الأرشيف.');

  let parsed: unknown;
  try {
    parsed = JSON.parse(await documentEntry.async('string')) as unknown;
  } catch {
    throw new Error('ملف بيانات النسخة غير صالح أو تالف.');
  }
  if (!isRecord(parsed) || parsed.format !== BACKUP_FORMAT || parsed.version !== BACKUP_VERSION || !Array.isArray(parsed.blobIds)) {
    throw new Error('صيغة النسخة غير مدعومة. استخدم نسخة NEXO حديثة.');
  }
  const rawBlobIds = parsed.blobIds;
  if (!rawBlobIds.every((id) => typeof id === 'string' && ID_PATTERN.test(id)) || new Set(rawBlobIds).size !== rawBlobIds.length) {
    throw new Error('قائمة ملفات النسخة غير صالحة.');
  }

  let workspace: WorkspaceState;
  try {
    workspace = normalizeImportedWorkspace(parsed.workspace);
  } catch (error) {
    throw new Error(error instanceof Error ? error.message : 'بيانات مساحة العمل غير صالحة.');
  }
  if (!workspace.name.trim()) throw new Error('النسخة لا تحتوي على اسم مستخدم محفوظ.');
  if (workspace.projects.some((project) => !project.name.trim()) || workspace.tasks.some((task) => !task.name.trim())) {
    throw new Error('تحتوي النسخة على مشروع أو مهمة بلا اسم.');
  }

  const localFileIds = new Set(workspace.files.filter((item) => item.localBlob).map((item) => item.id));
  if (rawBlobIds.some((id) => !localFileIds.has(id))) throw new Error('تحتوي النسخة على محتوى ملف غير مرتبط ببياناته.');

  const blobs = new Map<string, Blob>();
  const missingFiles: string[] = [];
  const files = [...workspace.files];
  for (const id of rawBlobIds as string[]) {
    const fileIndex = files.findIndex((item) => item.id === id);
    if (fileIndex < 0) throw new Error('تحتوي النسخة على ملف غير معروف.');
    const entry = zip.file(blobPath(id));
    if (!entry) {
      missingFiles.push(files[fileIndex].name);
      files[fileIndex] = { ...files[fileIndex], localBlob: false };
      continue;
    }
    let blob: Blob;
    try {
      blob = await entry.async('blob');
    } catch {
      throw new Error(`تعذر استعادة الملف «${files[fileIndex].name}». لم تتغير مساحة العمل الحالية.`);
    }
    if (blob.size > MAX_LOCAL_FILE_BYTES || blob.size !== files[fileIndex].size) {
      throw new Error(`حجم الملف «${files[fileIndex].name}» لا يطابق معلومات النسخة. لم تتغير مساحة العمل الحالية.`);
    }
    blobs.set(id, blob);
  }

  workspace = { ...workspace, files, metrics: { completedTasks: workspace.tasks.filter((task) => task.status === 'مكتملة').length, fileCount: files.length, recentActivity: workspace.activities.length } };
  return { workspace, blobs, missingFiles };
}
