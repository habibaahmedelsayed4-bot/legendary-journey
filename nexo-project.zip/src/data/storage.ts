import { createInitialState, getProjectProgress, getProjectTaskCount, MAX_LOCAL_FILE_BYTES, STATE_KEY, type ActivityItem, type Project, type ProjectStatus, type Task, type TaskStatus, type WorkspaceFile, type WorkspaceState } from './model';

const DB_NAME = 'nexo-local-files';
const STORE_NAME = 'blobs';

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value && typeof value === 'object' && !Array.isArray(value));
}

function isDemoId(id: string, prefix: string): boolean {
  return new RegExp(`^${prefix}-\\d+$`).test(id);
}

function validDateString(value: unknown): value is string {
  return typeof value === 'string' && value.length > 0 && !Number.isNaN(Date.parse(value));
}

function normalizeProject(value: unknown): Project | null {
  if (!isRecord(value) || typeof value.id !== 'string' || typeof value.name !== 'string') return null;
  const status: ProjectStatus = value.status === 'قيد المراجعة' || value.status === 'مكتمل' ? value.status : 'قيد التنفيذ';
  return {
    id: value.id,
    name: value.name,
    description: typeof value.description === 'string' ? value.description : '',
    progress: 0,
    status,
    updatedAt: validDateString(value.updatedAt) ? value.updatedAt : null,
    tasksCount: 0,
    color: typeof value.color === 'string' ? value.color : '#6d91ff',
    archived: value.archived === true,
  };
}

function normalizeTask(value: unknown): Task | null {
  if (!isRecord(value) || typeof value.id !== 'string' || typeof value.name !== 'string' || typeof value.projectId !== 'string') return null;
  const priority = value.priority === 'منخفضة' || value.priority === 'عالية' ? value.priority : 'متوسطة';
  const status: TaskStatus = value.status === 'قيد التنفيذ' || value.status === 'مكتملة' ? value.status : 'لم تبدأ';
  const dueDate = typeof value.dueDate === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value.dueDate) ? value.dueDate : '';
  return { id: value.id, name: value.name, projectId: value.projectId, priority, status, dueDate };
}

function normalizeFile(value: unknown): WorkspaceFile | null {
  if (!isRecord(value) || typeof value.id !== 'string' || typeof value.name !== 'string') return null;
  const size = typeof value.size === 'number' && Number.isFinite(value.size) ? Math.max(0, value.size) : 0;
  return {
    id: value.id,
    name: value.name,
    type: typeof value.type === 'string' ? value.type : 'FILE',
    size,
    date: validDateString(value.date) ? value.date : '',
    owner: typeof value.owner === 'string' ? value.owner : '',
    localBlob: value.localBlob === true,
    ...(typeof value.projectId === 'string' ? { projectId: value.projectId } : {}),
  };
}

function normalizeActivity(value: unknown): ActivityItem | null {
  if (!isRecord(value) || typeof value.id !== 'string' || typeof value.title !== 'string') return null;
  const kind = value.kind === 'task' || value.kind === 'file' || value.kind === 'settings' ? value.kind : 'project';
  return {
    id: value.id,
    title: value.title,
    description: typeof value.description === 'string' ? value.description : '',
    createdAt: validDateString(value.createdAt) ? value.createdAt : null,
    kind,
    ...(typeof value.projectId === 'string' ? { projectId: value.projectId } : {}),
  };
}

function migrateWorkspace(value: unknown): WorkspaceState {
  const defaults = createInitialState();
  const parsed = isRecord(value) ? value : {};
  const oldProjects = (Array.isArray(parsed.projects) ? parsed.projects : []).map(normalizeProject).filter((project): project is Project => Boolean(project));
  const oldTasks = (Array.isArray(parsed.tasks) ? parsed.tasks : []).map(normalizeTask).filter((task): task is Task => Boolean(task));
  const userTasks = oldTasks.filter((task) => !isDemoId(task.id, 'task'));
  const retainedProjectIds = new Set(oldProjects.filter((project) => !isDemoId(project.id, 'project')).map((project) => project.id));

  for (const task of userTasks) {
    if (oldProjects.some((project) => project.id === task.projectId)) retainedProjectIds.add(task.projectId);
  }

  const projectIds = new Set(oldProjects.filter((project) => retainedProjectIds.has(project.id)).map((project) => project.id));
  const tasks = userTasks.filter((task) => projectIds.has(task.projectId));
  const projects = oldProjects
    .filter((project) => projectIds.has(project.id))
    .map((project) => ({
      ...project,
      tasksCount: getProjectTaskCount(project.id, tasks),
      progress: getProjectProgress(project.id, tasks),
    }));
  const files = (Array.isArray(parsed.files) ? parsed.files : [])
    .map(normalizeFile)
    .filter((file): file is WorkspaceFile => Boolean(file) && !isDemoId((file as WorkspaceFile).id, 'file'))
    .map((file) => file.projectId && !projectIds.has(file.projectId) ? { ...file, projectId: undefined } : file);
  const activities = (Array.isArray(parsed.activities) ? parsed.activities : [])
    .map(normalizeActivity)
    .filter((activity): activity is ActivityItem => Boolean(activity) && !isDemoId((activity as ActivityItem).id, 'activity'));
  const oldPreferences = isRecord(parsed.preferences) ? parsed.preferences : {};

  return {
    ...defaults,
    name: typeof parsed.name === 'string' ? parsed.name.trim().slice(0, 32) : defaults.name,
    workspaceName: typeof parsed.workspaceName === 'string' ? parsed.workspaceName.trim().slice(0, 40) || defaults.workspaceName : defaults.workspaceName,
    preferences: {
      theme: oldPreferences.theme === 'light' ? 'light' : 'dark',
      localAlerts: typeof oldPreferences.localAlerts === 'boolean' ? oldPreferences.localAlerts : oldPreferences.emailNotifications === true,
      projectNotifications: oldPreferences.projectNotifications !== false,
      taskNotifications: oldPreferences.taskNotifications !== false,
    },
    projects,
    tasks,
    files,
    activities,
    metrics: {
      completedTasks: tasks.filter((task) => task.status === 'مكتملة').length,
      fileCount: files.length,
      recentActivity: activities.length,
    },
  };
}

export function loadWorkspace(): WorkspaceState {
  try {
    const stored = localStorage.getItem(STATE_KEY);
    if (!stored) return createInitialState();
    return migrateWorkspace(JSON.parse(stored) as unknown);
  } catch {
    return createInitialState();
  }
}

export function normalizeImportedWorkspace(value: unknown): WorkspaceState {
  if (!isRecord(value) || !Array.isArray(value.projects) || !Array.isArray(value.tasks) || !Array.isArray(value.files) || !Array.isArray(value.activities)) {
    throw new Error('النسخة لا تحتوي على بنية مساحة NEXO صالحة.');
  }
  if (typeof value.name !== 'string' || typeof value.workspaceName !== 'string' || !isRecord(value.preferences)) {
    throw new Error('النسخة تفتقد الاسم أو الإعدادات المطلوبة.');
  }
  return migrateWorkspace(value);
}

export function saveWorkspace(state: WorkspaceState): boolean {
  try {
    localStorage.setItem(STATE_KEY, JSON.stringify(state));
    return true;
  } catch {
    window.dispatchEvent(new CustomEvent('nexo:storage-error'));
    return false;
  }
}

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (!('indexedDB' in window)) {
      reject(new Error('التخزين المحلي للملفات غير متاح في هذا المتصفح.'));
      return;
    }
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) db.createObjectStore(STORE_NAME);
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error('تعذر فتح مساحة الملفات المحلية.'));
  });
}

export async function saveLocalFile(id: string, file: File): Promise<void> {
  if (file.size > MAX_LOCAL_FILE_BYTES) throw new Error('الحد الأقصى للملف الواحد هو 20 ميغابايت.');
  const db = await openDatabase();
  try {
    await new Promise<void>((resolve, reject) => {
      const transaction = db.transaction(STORE_NAME, 'readwrite');
      transaction.objectStore(STORE_NAME).put(file, id);
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error ?? new Error('تعذر حفظ الملف على هذا الجهاز.'));
      transaction.onabort = () => reject(transaction.error ?? new Error('أُلغي حفظ الملف.'));
    });
  } finally { db.close(); }
}

export async function getLocalFile(id: string): Promise<Blob | undefined> {
  const db = await openDatabase();
  try {
    return await new Promise<Blob | undefined>((resolve, reject) => {
      const request = db.transaction(STORE_NAME, 'readonly').objectStore(STORE_NAME).get(id);
      request.onsuccess = () => resolve(request.result as Blob | undefined);
      request.onerror = () => reject(request.error ?? new Error('تعذر فتح الملف المحلي.'));
    });
  } finally { db.close(); }
}

export async function deleteLocalFiles(ids: string[]): Promise<void> {
  if (ids.length === 0) return;
  const db = await openDatabase();
  try {
    await new Promise<void>((resolve, reject) => {
      const transaction = db.transaction(STORE_NAME, 'readwrite');
      const store = transaction.objectStore(STORE_NAME);
      ids.forEach((id) => store.delete(id));
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error ?? new Error('تعذر حذف الملف من تخزين المتصفح.'));
      transaction.onabort = () => reject(transaction.error ?? new Error('أُلغي حذف الملف.'));
    });
  } finally { db.close(); }
}

export async function replaceLocalFiles(files: Map<string, Blob>): Promise<void> {
  const db = await openDatabase();
  try {
    await new Promise<void>((resolve, reject) => {
      const transaction = db.transaction(STORE_NAME, 'readwrite');
      const store = transaction.objectStore(STORE_NAME);
      store.clear();
      for (const [id, blob] of files) store.put(blob, id);
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error ?? new Error('تعذر استعادة الملفات المحلية.'));
      transaction.onabort = () => reject(transaction.error ?? new Error('أُلغيت استعادة الملفات المحلية.'));
    });
  } finally { db.close(); }
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} بايت`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} كيلوبايت`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} ميغابايت`;
}
